//Braden Lewis
//Ashok Adhikari
//Professor Goulden
//Voting Project
//C++
// WE LOVE C++ <3
#include <iostream>
#include <algorithm> 
#include <string>
#include <fstream>
#include "Governor.h"
#include "sheriff.h"

using namespace std;

int main()
{

	Governor gov;
	Sheriff sh;

	// Variables

	int age;
	int duration;
	string firstName;
	string lastName;
	string somebody;
	string sex;
	string county;
	string party;
	string chosen;
	string confirm;

	//Registration
	cout << "Welcome to the - Vote by PROGRAM - PROGRAM!" << endl;
	cout << endl;

	cout << "How old are you? -> ";
	cin >> age;
	cout << endl;

	cout << "How many months have you lived in Oklahoma? -> ";
	cin >> duration;


	if (age >= 18 && duration >= 12)
	{
		cout << "You are eligable to vote!!!" << endl;
		cout << "------------------------------------------------------";
		cout << endl;
		cout << "What is your First name? -> ";
		cin >> firstName;
		transform(firstName.begin(), firstName.end(), firstName.begin(), ::toupper);
		cout << endl;
		cout << "What is your Last name? -> ";
		cin >> lastName;
		transform(lastName.begin(), lastName.end(), lastName.begin(), ::toupper);
		cout << endl;

		cout << "Gender: Male or Female? -> ";
		cin >> sex;
		transform(sex.begin(), sex.end(), sex.begin(), ::toupper);
		cout << endl;

		if (sex == "MALE" || sex == "FEMALE")
		{
		}
		else
		{
			cout << "Sorry we are only accepting Male or Female voters. Thanks for voting by PROGRAM!!!" << endl;
			exit(0);
		}


		cout << "Counties to choose from: Grady, Oklahoma, or Cimarron" << endl;
		cout << "What county do you live in? -> ";
		cin >> county;
		transform(county.begin(), county.end(), county.begin(), ::toupper);

		cout << "---------------- Welcome to the C++ Voting System-----------------";
		cout << endl;
		cout << " --------------- Information Verified ----------------------";
		cout << endl;
		cout << " Name   : " << firstName + " " + lastName << endl << " Sex    : " << sex << endl << " Age    : " << age << endl
			<< " County : " << county << endl;
		cout << " Thanks for Registration" << endl;
		cout << "-------------------------------------------------------------------" << endl;
		cout << endl;


		//Time to Vote
		cout << " Whom are you voting For ? " << endl << " 1) Sheriff " << endl << endl << " 2) Governor*" << endl;
		cin >> somebody;
		transform(somebody.begin(), somebody.end(), somebody.begin(), ::toupper);
		cout << endl;


		if (somebody == "GOVERNOR")
		{
			cout << "What party are you voting for today? 'Republican or Democrat' ";
			cin >> party;
			transform(party.begin(), party.end(), party.begin(), ::toupper);

			if (party == "REPUBLICAN")
			{
				cout << "----Republican Governors----" << endl;
				//Republican Gov.
				gov.repGovernor1();
				gov.repGovernor2();
				gov.repGovernor3();
				cout << endl;
				cout << endl;
				cout << "Which governor are you voting for today? -> *last name only*";
				cin >> chosen;
				transform(chosen.begin(), chosen.end(), chosen.begin(), ::toupper);
				cout << "You have placed a vote for " << chosen << endl;
				cout << "Confirmation: Are you sure that's who you want to vote for?" "*Yes or No*";
				cin >> confirm;
				transform(confirm.begin(), confirm.end(), confirm.begin(), ::toupper);
				cout << endl;
				if (confirm == "YES")
				{
					cout << "Thanks for voting through PROGRAM. " << chosen << " will be thrilled!!!" << endl;
				}
				else
				{
					exit(0);
				}
			}


			else
			{
				cout << "----Democratic Governors----" << endl;
				//Democratic Gov.
				gov.demGovernor1();
				gov.demGovernor2();
				gov.demGovernor3();
				cout << endl;
				cout << endl;
				cout << "Which governor are you voting for today? -> *last name only*";
				cin >> chosen;
				transform(chosen.begin(), chosen.end(), chosen.begin(), ::toupper);
				cout << "You have placed a vote for " << chosen << endl;
				cout << "Confirmation: Are you sure that's who you want to vote for?" "*Yes or No*";
				cin >> confirm;
				transform(confirm.begin(), confirm.end(), confirm.begin(), ::toupper);
				cout << endl;
				if (confirm == "YES")
				{
					cout << "Thanks for voting through PROGRAM. " << chosen << " will be thrilled!!!" << endl;
				}
				else
				{
					exit(0);
				}
			}
		}
		else if (somebody == "SHERIFF")
		{
			cout << " You live in " << county << " County" << endl;
			// Oklahoma Sheriff
			if (county == "OKLAHOMA")
			{
				sh.OKSheriff1();
				sh.OKSheriff2();
				sh.OKSheriff3();
				cout << endl;
				cout << endl;
				cout << "Which sheriff are you voting for today? -> *last name only*";
				cin >> chosen;
				transform(chosen.begin(), chosen.end(), chosen.begin(), ::toupper);
				cout << "You have placed a vote for " << chosen << endl;
				cout << "Confirmation: Are you sure that's who you want to vote for?" "*Yes or No*";
				cin >> confirm;
				transform(confirm.begin(), confirm.end(), confirm.begin(), ::toupper);
				cout << endl;
				if (confirm == "YES")
				{
					cout << "Thanks for voting through PROGRAM. " << chosen << " will be thrilled!!!" << endl;
				}
				else
				{
					exit(0);
				}
			}
			// Grady Sheriff
			else if (county == "GRADY")
			{
				sh.GRSheriff1();
				sh.GRSheriff2();
				sh.GRSheriff3();
				cout << endl;
				cout << endl;
				cout << "Which sheriff are you voting for today? -> *last name only*";
				cin >> chosen;
				transform(chosen.begin(), chosen.end(), chosen.begin(), ::toupper);
				cout << "You have placed a vote for " << chosen << endl;
				cout << "Confirmation: Are you sure that's who you want to vote for?" "*Yes or No*";
				cin >> confirm;
				transform(confirm.begin(), confirm.end(), confirm.begin(), ::toupper);
				cout << endl;
				if (confirm == "YES")
				{
					cout << "Thanks for voting through PROGRAM. " << chosen << " will be thrilled!!!" << endl;
				}
				else
				{
					exit(0);
				}
			}
			// Cimarron Sheriff
			else if (county == "CIMARRON")
			{
				cout << "----Cimarron Shierff----" << endl;
				sh.CMSheriff1();
				sh.CMSheriff2();
				sh.CMSheriff3();
				cout << endl;
				cout << endl;
				cout << "Which sheriff are you voting for today? -> *last name only*";
				cin >> chosen;
				transform(chosen.begin(), chosen.end(), chosen.begin(), ::toupper);
				cout << "You have placed a vote for " << chosen << endl;
				cout << "Confirmation: Are you sure that's who you want to vote for?" "*Yes or No*";
				cin >> confirm;
				transform(confirm.begin(), confirm.end(), confirm.begin(), ::toupper);
				cout << endl;
				if (confirm == "YES")
				{
					cout << "Thanks for voting through PROGRAM. " << chosen << " will be thrilled!!!" << endl;
				}
				else
				{
					exit(0);
				}
			}
		}
		else
		{
			cout << "Sorry, we only accept 'Governor' and 'Sheriff'. Thanks for voting by PROGRAM!" << endl;
			exit(0);
		}


	}

	else
	{
		cout << endl;

		cout << "Thanks for stopping by!" << endl;
		cout << endl;

	    cout <<"You you must be atleast 18 years old and have lived in Oklahoma for atleast 12 months to register to vote." << endl;
		exit(0);
	}



	return 0;
}
