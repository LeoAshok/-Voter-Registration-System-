#pragma once
#include <string>
//Sheriff.h

using namespace std;

class Sheriff {

private:
public:

	//OKlahoma County
	void OKSheriff1();
	void OKSheriff2();
	void OKSheriff3();

	//Grady County
	void GRSheriff1();
	void GRSheriff2();
	void GRSheriff3();

	//Cimarron County
	void CMSheriff1();
	void CMSheriff2();
	void CMSheriff3();


};