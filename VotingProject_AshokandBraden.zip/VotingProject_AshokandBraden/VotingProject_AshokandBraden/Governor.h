#pragma once
#include <string>

using namespace std;

class Governor {

private:
	
	
public:

	//Republican
	void repGovernor1();
	void repGovernor2();
	void repGovernor3();
	
	//Democratic
	void demGovernor1();
	void demGovernor2();
	void demGovernor3();

};