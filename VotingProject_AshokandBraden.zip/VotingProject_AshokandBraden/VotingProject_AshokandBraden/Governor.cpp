//Governor.cpp
//Braden Lewis
//Ashok Adhikari

#include "Governor.h"
#include <iostream>
#include <string>
 
//Republican Gov.

void Governor::repGovernor1()
{
	cout << "------------------------------------------------------------------------------" << endl;
	cout << " ******* Kevin Stitt ******* " << endl;
	cout << " Info: born December 28, 1972 - Grew up in Norman Oklahoma and graduated from OSU with a degree in accounting." <<
		" He Founded and is the former chairman and CEO of Gateway Mortgage Group." << endl;
	cout << endl;
	cout << " Stitt is a Pro-Life advocate - will defend Oklahomans' constitutional right to bear arms." << endl;
	cout << "------------------------------------------------------------------------------" << endl;
	cout << endl;
}

void Governor::repGovernor2()
{
	cout << "------------------------------------------------------------------------------" << endl;
	cout << " ******* Mary Fallin ******* " << endl;
	cout << "Info: born December 9, 1954 - Born in Warrensburg Missouri, raised in Tecumseh Oklahoma where mother and father" <<
		" served terms as mayor, both of her parents were Democratic as well as Fallin until she turned 21 and switched to Republican." <<
		" Recieved bachelors from OSU in human and environmental sciences and family relationships and child development." << endl;
	cout << endl;
	cout << " Fallin stands to eliminate Oklahoma state income tax, while expandind states tax - anti-abortionist." << endl;
	cout << "------------------------------------------------------------------------------" << endl;
	cout << endl;
}

void Governor::repGovernor3()
{
	cout << "------------------------------------------------------------------------------" << endl;
	cout << " ******* Henry Bellmon ******* " << endl;
	cout << " Info: born September 3, 1921 - Born in Tonkawa Oklahoma. Graduated from Oklahoma A & M (now OSU) in 1942 with" <<
		" bachelors in agriculture. Served as Lieutenant in the U.S. Marines as tank platoon leader in WWII. he was" <<
		" awarded legion of merit and a silver star." << endl;
	cout << endl;
	cout << " Bellmon is for school reform - Passage of the House Bill - Will not quit!" << endl;
	cout << "------------------------------------------------------------------------------" << endl;
	cout << endl;
}

//Democratic Gov.

void Governor::demGovernor1()
{
	cout << "------------------------------------------------------------------------------" << endl;
	cout << " ******* Brad Henry ******* " << endl;
	cout << " Info: born July 10, 1965 - Born in Shawnee Oklahoma. His father was a prominent judge and former state representative." <<
		" Graduated as a presidents leadership scholar with a bachelors in economics in 1985." << endl;
	cout << endl;
	cout << " Henry is Pro-Choice - supports expanding public healthcare - against gun control." << endl;
	cout << "------------------------------------------------------------------------------" << endl;
	cout << endl;
}

void Governor::demGovernor2()
{
	cout << "------------------------------------------------------------------------------" << endl;
	cout << " ******* David Boren ******* " << endl;
	cout << " Info: born April 21, 1941 - Born in Washington D.C. Graduated from Yale University in 1963. majored in American History." <<
		" He was selected as Rhodes scholar, then earned his masters in philosophy, politics, and in economics from" <<
		" University of Oxford in 1965. Later served in Oklahoma's National Guard." << endl;
	cout << endl;
	cout << " Boren kept with the anti-establishment movements - pledges to bring fundamental reforms to the state government." << endl;
	cout << "------------------------------------------------------------------------------" << endl;
	cout << endl;
}

void Governor::demGovernor3()
{
	cout << "------------------------------------------------------------------------------" << endl;
	cout << " ******* George Nigh ******* " << endl;
	cout << " Info: born June 9, 1927 - Born in McAlester Oklahoma, Served in the U.S. Navy, graduated from East Central State College in 1951." <<
		" Was a teacher at McAlester High School." << endl;
	cout << endl;
	cout << " Nigh will establish Franchise taxes in Oklahoma - Will reorganize executive branch into agency function categories." << endl;
	cout << endl;
	cout << "------------------------------------------------------------------------------" << endl;
}