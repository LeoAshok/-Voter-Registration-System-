//Sheriff.cpp
//Braden Lewis
//Ashok Adhikari

#include "Sheriff.h"
#include <iostream>
#include <string>

//Oklahoma County.

void Sheriff::OKSheriff1()
{
	cout << "------------------------------------------------------------------------------" << endl;
	cout << " ******* John Whetsel ******* " << endl;
	cout << " Info: Began his Law enforcement in career in 1967 " <<
		    " served Choctaw Chief Police for 21 Years." << endl;
	cout << " Awarded with 'The Oklahoma Rifle Association Law Enforcement Officer of the year (2011)'," <<
		    " Shierf of the Year(2006)." << endl;
	cout << endl;
	cout << " Whetsel stands to make the county safer." << endl;
	cout << "------------------------------------------------------------------------------" << endl;
	cout << endl;
}

void Sheriff::OKSheriff2()
{
	cout << "------------------------------------------------------------------------------" << endl;
	cout << " ******* Bob Turner ******* " << endl;
	cout << " Info: Started his law enforcement career as jailer in 1934. " <<
		    " Became a field deputy and investigator with the County Attorney's Office. " << endl;
	cout << " Awarded with The Citizens for Police Improvement Award," << "Outstanding Public Official Award" << endl;
	cout << endl;
	cout << " Turner stands to provide health care to the prisoners and better the condition  of the county jail." << endl;
	cout << "------------------------------------------------------------------------------" << endl;
	cout << endl;
}

void Sheriff::OKSheriff3()
{ 
	cout << "------------------------------------------------------------------------------" << endl;
	cout << " ******* P.D. Taylor ******* " << endl;
	cout << " Info: Started his law enforcement career in Police department in 1968. " <<
		" Worked as UnderShierff for 14 years" << endl;
	cout << "He endorsed Fraternal Order of Police Lodge" << endl;
	cout << endl;
	cout << " Taylor stands to protect the inmates when they are in custody,protect public and make the employees proud." << endl;
	cout << "------------------------------------------------------------------------------" << endl;
	cout << endl;
}

//Grady County

void Sheriff::GRSheriff1()
{ 
	cout << "------------------------------------------------------------------------------" << endl;
	cout << " ******* Ron Taylor ******* " << endl;
	cout << " Info: Started his law enforcement career from Kansas before he moved to Grady Oklahoma Shierf. " << endl;
	cout << endl;
	cout << " Taylor stands to protect the public, and maintain law and order." << endl;
	cout << "------------------------------------------------------------------------------" << endl;
	cout << endl;
}
void Sheriff::GRSheriff2()
{
	cout << "------------------------------------------------------------------------------" << endl;
	cout << " ******* Phil Belvins ******* " << endl;
	cout << " Info: Started his law enforcement career as Military Police. " <<
		" Worked as UnderShierff for 14 years" << endl;
	cout << endl;
	cout << " Taylor stands to protect the citizens ." << endl;
	cout << "------------------------------------------------------------------------------" << endl;
	cout << endl;
}

void Sheriff::GRSheriff3()
{
	cout << "------------------------------------------------------------------------------" << endl;
	cout << " ****** Jim Weir ******* " << endl;
	cout << " Info: Started his law enforcement career in Police department in 1979. " <<
		" Worked in Oklahoma City Police department for 25 Years" << endl;
	cout << " Nominated  for Oklahoma City's Officer Award." << endl;
	cout << endl;
	cout << " Weir stands to protect the citizens and wipe out crime from the county." << endl;
	cout << "------------------------------------------------------------------------------" << endl;
	cout << endl;
}

//Cimarron County

void Sheriff::CMSheriff1()
{
	cout << "------------------------------------------------------------------------------" << endl;
	cout << " ******* Bob White ******* " << endl;
	cout << " Info: Started his law enforcement career in Police department in 2001. " << endl;
	cout << endl;
	cout << " White stands to protect the inmates when they are in custody,protect public and make the employees proud." << endl;
	cout << "------------------------------------------------------------------------------" << endl;
	cout << endl;
}

void Sheriff::CMSheriff2()
{
	cout << "------------------------------------------------------------------------------" << endl;
	cout << " ******* Leon Apple ******* " << endl;
	cout << " Info: Started his law enforcement career in Police department. " << endl;
	cout << endl;
	cout << " Apple stands to work against the drugs and protect the people from the crimes." << endl;
	cout << "------------------------------------------------------------------------------" << endl;
	cout << endl;
}

void Sheriff::CMSheriff3()
{
	cout << "------------------------------------------------------------------------------" << endl;
	cout << " ******* Kevin McIntyre ******* " << endl;
	cout << " Info: Started his law enforcement career in Police department. " <<
		" Worked as UnderShierff " << endl;
	cout << endl;
	cout << " Mctine stands to protect thecounty from crimes." << endl;
	cout << "------------------------------------------------------------------------------" << endl;
	cout << endl;
}

